﻿/*
 Copyright (c) 2003-2019, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang("placeholder","et",{title:"Kohahoidja omadused",toolbar:"Kohahoidja loomine",name:"Kohahoidja nimi",invalidName:"Kohahoidja ei saa olla tühi ega sisaldada ühtegi järgnevatest märkidest: [, ], \x3c, \x3e",pathName:"kohahoidja"});