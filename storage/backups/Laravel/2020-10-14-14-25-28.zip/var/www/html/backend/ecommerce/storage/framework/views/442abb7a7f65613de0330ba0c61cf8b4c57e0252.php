<?php
  $defaultBreadcrumbs = [
    trans('backpack::crud.admin') => backpack_url('dashboard'),
    $crud->entity_name_plural => url($crud->route),
    trans('backpack::crud.edit').' '.trans('backpack::langfilemanager.texts') => false,
  ];

  // if breadcrumbs aren't defined in the CrudController, use the default breadcrumbs
  $breadcrumbs = $breadcrumbs ?? $defaultBreadcrumbs;
?>

<?php $__env->startSection('header'); ?>
	<section class="container-fluid">
	  <h2>
        <span class="text-capitalize"><?php echo e(trans('backpack::langfilemanager.translate')); ?></span>
        <small><?php echo e(trans('backpack::langfilemanager.site_texts')); ?>.</small>

        <?php if($crud->hasAccess('list')): ?>
          <small><a href="<?php echo e(url($crud->route)); ?>" class="hidden-print font-sm"><i class="fa fa-angle-double-left"></i> <?php echo e(trans('backpack::crud.back_to_all')); ?> <span><?php echo e($crud->entity_name_plural); ?></span></a></small>
        <?php endif; ?>
	  </h2>
	</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Default box -->
  <div class="box">
  	<div class="box-header with-border">
	  <h3 class="box-title float-right pr-1">
		<small>
			 &nbsp; <?php echo e(trans('backpack::langfilemanager.switch_to')); ?>: &nbsp;
			<select name="language_switch" id="language_switch">
				<?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<option value="<?php echo e(url(config('backpack.base.route_prefix', 'admin')."/language/texts/{$lang->abbr}")); ?>" <?php echo e($currentLang == $lang->abbr ? 'selected' : ''); ?>><?php echo e($lang->name); ?></option>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</select>
		</small>
	  </h3>
	</div>
    <div class="box-body">
		<ul class="nav nav-tabs">
			<?php $__currentLoopData = $langFiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<li class="nav-item">
				<a class="nav-link <?php echo e($file['active'] ? 'active' : ''); ?>" href="<?php echo e($file['url']); ?>"><?php echo e($file['name']); ?></a>
			</li>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</ul>
		<section class="tab-content p-3 lang-inputs">
		<?php if(!empty($fileArray)): ?>
			<form
				method="post"
				id="lang-form"
				class="form-horizontal"
				data-required="<?php echo e(trans('admin.language.fields_required')); ?>"
		  		action="<?php echo e(url(config('backpack.base.route_prefix', 'admin')."/language/texts/{$currentLang}/{$currentFile}")); ?>"
		  		>
				<?php echo csrf_field(); ?>

				<div class="form-group row">
					<div class="col-sm-2">
						<h5><?php echo e(trans('backpack::langfilemanager.key')); ?></h5>
					</div>
					<div class="hidden-sm hidden-xs col-md-5">
						<h5><?php echo e(trans('backpack::langfilemanager.language_text', ['language_name' => $browsingLangObj->name])); ?></h5>
					</div>
					<div class="col-sm-10 col-md-5">
						<h5><?php echo e(trans('backpack::langfilemanager.language_translation', ['language_name' => $currentLangObj->name])); ?></h5>
					</div>
				</div>
				<?php echo $langfile->displayInputs($fileArray); ?>

				<hr>
				<div class="text-center">
					<button type="submit" class="btn btn-success submit"><?php echo e(trans('backpack::crud.save')); ?></button>
				</div>
				</form>
				<?php else: ?>
					<em><?php echo e(trans('backpack::langfilemanager.empty_file')); ?></em>
				<?php endif; ?>
			</section>
    </div><!-- /.card-body -->
    	<p><small><?php echo trans('backpack::langfilemanager.rules_text'); ?></small></p>
  </div><!-- /.card -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('after_scripts'); ?>
	<script>
		jQuery(document).ready(function($) {
			$("#language_switch").change(function() {
				window.location.href = $(this).val();
			})
		});
	</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make(backpack_view('layouts.top_left'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/backend/ecommerce/vendor/backpack/langfilemanager/src/resources/views/translations.blade.php ENDPATH**/ ?>