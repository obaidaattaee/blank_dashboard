﻿/*
 Copyright (c) 2003-2019, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang("placeholder","sr",{title:"Подешавање резервног места",toolbar:"Припремање резервног места",name:"Назив резервног места",invalidName:"Резервно место не може бити празно, не може да садржи следеће карактере: [, ], \x3c, \x3e",pathName:"Резервно место"});